# ============================================================
#  ArbPlus File Association Uninstaller (Windows)
#  Removes: .arb double-click to run, context menu entries
#
#  Usage:  powershell -ExecutionPolicy Bypass -File uninstall_arb_assoc.ps1
# ============================================================

$ErrorActionPreference = "Continue"
$regBase = "HKCU:\Software\Classes"

# Remove .arb association
$arbKey = "$regBase\.arb"
if (Test-Path $arbKey) {
    $cur = (Get-ItemProperty -Path $arbKey -Name "(Default)" -ErrorAction SilentlyContinue)."(Default)"
    if ($cur -eq "ArbPlus.Script") {
        Remove-Item -Path $arbKey -Recurse -Force
        Write-Host "[ArbPlus] Removed .arb association" -ForegroundColor Green
    } else {
        Write-Host "[ArbPlus] .arb is associated with '$cur' — not removing (not ours)" -ForegroundColor Yellow
    }
}

# Remove ArbPlus.Script file type
$scriptKey = "$regBase\ArbPlus.Script"
if (Test-Path $scriptKey) {
    Remove-Item -Path $scriptKey -Recurse -Force
    Write-Host "[ArbPlus] Removed ArbPlus.Script file type" -ForegroundColor Green
}

# Notify shell
$signature = @"
using System;
using System.Runtime.InteropServices;
public class Shell32 {
    [DllImport("shell32.dll")]
    public static extern void SHChangeNotify(int wEventId, int uFlags, IntPtr dwItem1, IntPtr dwItem2);
}
"@
try {
    Add-Type -TypeDefinition $signature -ErrorAction SilentlyContinue
    [Shell32]::SHChangeNotify(0x08000000, 0x0000, [IntPtr]::Zero, [IntPtr]::Zero)
} catch {}

Write-Host ""
Write-Host "[ArbPlus] Uninstallation complete." -ForegroundColor Green
Write-Host "  .arb files will revert to their previous association." -ForegroundColor Gray
