# ArbPlus Usage Documentation

## Installation & Setup

### Running the Interpreter
```bash
python3 interpreter.py script.arb
```
The interpreter requires Python 3.8+. No external packages are needed — it uses only the standard library.

### Missing Toolchain Errors
The interpreter checks for required toolchains **lazily** (only when a feature is used):

| Feature | Required Tool | Error Message |
|---------|--------------|---------------|
| `c{ }` blocks | gcc, cc, or clang | "C block requires a C compiler (gcc/cc/clang) but none was found on PATH. Install a C compiler to use c{ } blocks." |
| `cmd{ }` blocks | cmd.exe (Windows) or sh (Linux/macOS) | Falls back to sh on non-Windows |
| `ps{ }` blocks | powershell or pwsh | Falls back to sh if not found |
| C/C++ extensions | gcc/cc/clang | "C/C++ extension requires a C compiler but none was found." |

### Bundling with PyInstaller
```bash
pip install pyinstaller
pyinstaller --onefile interpreter.py
# Result: dist/interpreter (standalone executable, no Python needed)
```

---

## Writing Your First .arb File

```arb
#meta {
    name: "MyFirstScript";
    version: "1.0";
    description: "Hello from ArbPlus";
}

print("Hello, World!");
print("Colored!", fg: cyan);
```

Run it:
```bash
python3 interpreter.py myfirst.arb
```

---

## File Structure
Every `.arb` file follows this order:
1. `#meta { ... }` — metadata block (optional but recommended)
2. `#use batch;` — shell declarations (optional)
3. `--OV print myprint;` — overrides (optional)
4. `--Function Role.Name() { ... }` — function definitions (optional)
5. Main body — executable statements

---

## Functions and Overrides

### Defining Functions
```arb
--Function pub.greet(name) {
    return "Hello, " .. name .. "!";
}

--Function util.calculate(x: int, y: int) {
    return add(x, y);
}
```

### Calling Functions
```arb
let msg = greet("World");
let sum = calculate(10, 20);
```

### Overrides (--OV)
```arb
--OV print myprint;
--OV len length;

myprint("This uses the overridden print!");
let n = length("hello");  // same as len("hello")
```
The original function name remains callable. The override creates an alias.

### Built-in Functions

| Category | Functions |
|----------|-----------|
| Arithmetic | `add(a,b)`, `sub(a,b)`, `mul(a,b)`, `div(a,b)`, `mod(a,b)`, `pow(a,b)` |
| String | `concat(...)`, `len(s)`, `upper(s)`, `lower(s)`, `trim(s)`, `split(s,d)`, `join(lst,d)`, `substr(s,n[,m])`, `replace(s,old,new)`, `contains(s,sub)` |
| I/O | `print(text, fg: color, bg: color)`, `input(prompt, fg: color, bg: color)` |
| Type | `toInt(v)`, `toFloat(v)`, `toString(v)`, `toBool(v)`, `typeof(v)` |
| File | `readFile(path)`, `fileExists(path)`, `writeFile(path,content,mode:)`, `buildFile(path,content)`, `encodeImage(path)`, `decodeImage(arb,path)`, `openMedia(path)`, `openBrowser(url)` |
| Addressing | `addr.hex(val)`, `addr.binary(val)`, `addr.meta("marker")`, `txtRC(row,col,data)` |
| Directory | `dir.list(path[,filter])`, `dir.name(path,newname)`, `dir.make(path,files)`, `dir.del(path)` |
| OS Globals | `snap.time()`, `count.time()`, `wait(m,s,ms)`, `cs()`, `cs(scheme)`, `locale.prf`, `locale.cur`, `locale.alt`, `locale.check(loc)`, `battery()`, `network()`, `screen()`, `os.name`, `os.version` |
| Extensions | `loadExt(path, lang)` |

---

## Type System Quick Reference

| Type | Description | Example |
|------|-------------|---------|
| `int` | 64-bit integer | `42`, `0x1A` |
| `float` | Double-precision | `3.14` |
| `string` | UTF-8 text | `"hello"` |
| `boolean` | true/false | `true`, `false` |
| `array` | Fixed, homogeneous | (constructed via builtins) |
| `list` | Dynamic, heterogeneous | `[1, "two", 3.0]` |
| `arb` | Tagged hex container | `arb{ 0x01("hi"), 0x02(42) }` |

### arb Sub-Type Tags
| Tag | Hex | Type |
|-----|-----|------|
| str | 0x01 | String |
| int | 0x02 | Integer |
| float | 0x03 | Float |
| bool | 0x04 | Boolean |
| image | 0x10 | Base64 image |
| raw | 0xFF | Raw bytes |

### Coercion
```arb
toInt("42")     // → 42
toFloat(42)     // → 42.0
toString(true)  // → "true"
toBool(0)       // → false
```

---

## File Operations Quick Reference

### Reading
```arb
if (fileExists("./data.txt")) {
    let content = readFile("./data.txt");
    print(content);
}
```

### Addressing
```arb
addr.hex(0x1A)           // → "0x1A"
addr.binary(1024)        // → "0b10000000000"
addr.meta("EXIF:DateTaken")
```

### txtRC (Row/Column Access)
```arb
let data = readFile("./data.csv");
txtRC(2, 3, data)  // row 2, col 3 (1-based indexing)
```
- 1-based indexing
- Auto-detects delimiter: tab, comma, semicolon, or whitespace
- Out of bounds raises error

### Writing
```arb
writeFile("./out.txt", "content");                     // overwrite (default)
writeFile("./out.txt", "content", mode: error);          // error if exists
buildFile("./out.txt", "content");                       // auto-rename if exists
```

### Image Encoding
```arb
let img = encodeImage("./photo.png");   // → arb with image tag
decodeImage(img, "./restored.png");      // write back to file
```

### Media & Browser
```arb
openMedia("./image.jpg");   // opens in OS default viewer
openBrowser("https://example.com");
```

---

## Directory Operations Quick Reference

```arb
dir.make("./newdir", "a.txt;b.txt;c.arb");   // creates dir with empty files
dir.list("./newdir");                         // all entries
dir.list("./newdir", "files");                // files only
dir.list("./newdir", "folders");              // folders only
dir.name("./newdir", "renamed");              // rename
dir.del("./newdir");                          // recursive delete
```

### Relative Paths
- `./` — current folder (relative to script location)
- `../` — parent folder
- `../../` — multi-level parent

---

## Control Flow Quick Reference

### Conditionals
```arb
if (x > 10) { print("big"); }
elif (x > 5) { print("medium"); }
else { print("small"); }

if (not isEmpty) { print("has data"); }
```

### Loops
```arb
for (i = 1 to 10) { print(i); }
for (i = 0 to 100 step 2) { print(i); }
for (item in myList) { print(item); }
while (x > 0) { x = x - 1; }
```

### break
```arb
for (i = 1 to 100) {
    if (i > 10) { break; }
}
```

### Ternary
```arb
let label = (score >= 60 ? "pass" : "fail");
```

### exit / quit
```arb
exit 1;   // terminate with code 1
quit;      // terminate with code 0
```

---

## I/O with Color

### Named Colors
```arb
print("error", fg: red);
print("warning", fg: yellow, bg: black);
print("success", fg: green);
input("Name: ", fg: cyan);
```

### Available Colors
black, red, green, yellow, blue, magenta, cyan, white, plus bright_ variants (bright_red, etc.)

### Hex Colors
```arb
print("custom", fg: #FF6600, bg: #1A1A2E);
```

---

## OS Globals Quick Reference

### Time
```arb
let ts = snap.time();                              // one-shot: "2026-07-23 12:39:00"
let detailed = snap.time(Year: 0, Month: 0, Day: 0); // "Year=2026, Month=7, Day=23"
let now = count.time();                              // live: re-samples on each call
wait(0, 2, 500);                                      // pause 2.5 seconds
```

### Color Scheme
```arb
let scheme = cs();       // "light" or "dark"
let isDark = cs(dark);    // true/false
let isLight = cs(light);  // true/false
```

### Locale
```arb
locale.prf               // preferred locale
locale.cur               // current active locale
locale.alt               // alternatives ("en-US, en-GB")
locale.check("en_GB")    // boolean: is locale available?
```

### Other Globals
```arb
battery()    // "85%"
network()    // true/false
screen()     // "1920x1080"
os.name      // "Linux"
os.version   // kernel version
```

---

## Extensions

### Loading
```arb
loadExt("./myext.py", "python");
loadExt("./myext.c", "c");
loadExt("./myext.cpp", "c++");
```

### Calling Extension Functions
```arb
let result = ext.myFunction(arg1, arg2);
```

### Writing a Python Extension
```python
def my_function(args, kwargs):
    # args is a list of ArbValue objects
    # kwargs is a dict of ArbValue objects
    val = args[0].py() if args else ""
    return f"Processed: {val}"  # return plain Python value

def register(engine):
    engine.register_extension("ext.myFunction", my_function)
    # Hooks: extend existing builtins
    engine.register_hook("snap.time", my_time_hook)

def my_time_hook(args, kwargs, original_func):
    import datetime
    return datetime.datetime.now().strftime("%H:%M:%S.%f")
```

### Writing a C Extension
```c
ArbValue ext_double(int argc, ArbValue* args) {
    ArbValue r;
    r.type = ARB_INT;
    r.data.int_val = args[0].data.int_val * 2;
    return r;
}

void arbplus_register(ArbEngine* engine) {
    engine->register_func("ext.double", ext_double);
}
```

---

## Common Pitfalls

| Pitfall | Fix |
|---------|-----|
| arb sub-type tag mixups | Check the tag map: str=0x01, int=0x02, float=0x03, bool=0x04 |
| Forgetting to declare a shell | Add `#use batch;` or `#use powershell;` before using `cmd{}`/`ps{}` |
| Off-by-one in txtRC | txtRC uses 1-based indexing (first row = 1, first column = 1) |
| Unsandboxed variable write paths | Validate paths before writing: check for `..` traversal |
| Confusing snap.time vs count.time | snap.time = one-shot; count.time = live/re-sampling |
| Not checking fileExists before readFile | Always check first: `if (fileExists(path)) { readFile(path); }` |
| `>` terminator vs comparison | Context-dependent: `>` alone = terminator, `>=` = comparison |
| Bare identifiers as arguments | Undefined identifiers fall back to string literals (for color names, enums) |
| Extension returns ArbValue | Return plain Python values; the interpreter wraps them automatically |

---

## Quick-Reference Syntax Table

| Feature | Syntax |
|---------|--------|
| Metadata | `#meta { name: "x"; version: "1.0"; }` |
| Declare shell | `#use batch;` |
| Import | `#import module;` |
| Override | `--OV print myprint;` |
| Function | `--Function pub.name(args) { body }` |
| Variable | `let x = value;` / `const x = value;` |
| String concat | `a .. b` or `concat(a, b)` |
| Swap | `a <> b` |
| Shell escape | `cmd{ shell code }` |
| Inline C | `c{ C code }` |
| arb literal | `arb{ 0x01("str"), 0x02(42) }` |
| if/elif/else | `if (cond) { } elif (cond) { } else { }` |
| not | `if (not cond) { }` |
| for range | `for (i = 1 to 10 step 2) { }` |
| for in | `for (item in list) { }` |
| while | `while (cond) { }` |
| break | `break;` |
| ternary | `(cond ? a : b)` |
| exit | `exit 0;` |
| colored print | `print(text, fg: red, bg: black)` |
| input | `input("prompt: ", fg: cyan)` |
| read file | `readFile(path)` |
| write file | `writeFile(path, content)` |
| build file | `buildFile(path, content)` |
| file exists | `fileExists(path)` |
| addr hex | `addr.hex(0x1A)` |
| txtRC | `txtRC(row, col, data)` |
| dir list | `dir.list(path, "files")` |
| dir make | `dir.make(path, "a.txt;b.txt")` |
| dir name | `dir.name(path, newname)` |
| dir del | `dir.del(path)` |
| snap time | `snap.time(Year: y)` |
| count time | `count.time(MS: 0)` |
| wait | `wait(minutes, seconds, ms)` |
| color scheme | `cs()` / `cs(dark)` |
| locale | `locale.prf` / `locale.check("en")` |
| load extension | `loadExt(path, lang)` |
| comment | `// single line` / `/* multi line */` |
| terminator | `;` (primary) or `>` (alternative) |
