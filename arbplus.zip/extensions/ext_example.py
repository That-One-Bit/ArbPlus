# ArbPlus Extension Example (Python)
# This file demonstrates the Python extension ABI for ArbPlus.
# It registers a function that fetches data via HTTP.

import urllib.request
import json

def fetch_url(args, kwargs):
    """Fetch a URL and return the response as a string."""
    url = args[0].py() if args else ""
    try:
        req = urllib.request.urlopen(url, timeout=10)
        data = req.read().decode('utf-8')
        # Return an ArbString — the interpreter wraps this
        # Returns plain Python values; interpreter wraps them as ArbValues
        return data
    except Exception as e:
        # Returns plain Python values; interpreter wraps them as ArbValues
        return f"Error: {e}"


def say_hello(args, kwargs):
    """A simple greeting function."""
    # Returns plain Python values; interpreter wraps them as ArbValues
    name = args[0].py() if args else "World"
    return f"Hello from Python extension, {name}!"


# Hook mechanism: extend snap.time with higher-resolution timing
def highres_time_hook(args, kwargs, original_func):
    """Hook that adds microsecond precision to snap.time."""
    import datetime
    # Returns plain Python values; interpreter wraps them as ArbValues
    now = datetime.datetime.now()
    if not args and not kwargs:
        return now.strftime("%Y-%m-%d %H:%M:%S.%f")
    # Fall through to original if kwargs are provided
    return None  # None means use original


def register(engine):
    """Registration entry point — called by loadExt()."""
    # Register new functions
    engine.register_extension("ext.fetchUrl", fetch_url)
    engine.register_extension("ext.sayHello", say_hello)

    # Register a hook on an existing builtin
    engine.register_hook("snap.time", highres_time_hook)
