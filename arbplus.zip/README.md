# ArbPlus — "A Really Bad Programming Language"

A hybrid scripting language with inline C, shell escapes, tagged binary containers, OS-level globals, and a Python-based tree-walking interpreter.

## Quick Start

```bash
# Run any .arb file
python3 interpreter.py examples/01_hello.arb

# Run all examples
./run_examples.sh
```

## What's Here

```
arbplus/
├── interpreter.py          ← The full interpreter (lexer, parser, evaluator, builtins)
├── run_examples.sh         ← Script to run all examples
├── examples/               ← Example .arb scripts (Step 16 worked examples)
│   ├── 01_hello.arb        ← Metadata, print, colored output
│   ├── 02_midcomplex.arb   ← Variables, functions, override, inline-if, shell-escape
│   ├── 03_stringswap.arb   ← Concatenation and single-line swap
│   ├── 04_controlflow.arb  ← Loops, break, not, ternary, if/elif/else
│   ├── 05_files.arb        ← readFile, txtRC, addr, writeFile, buildFile
│   ├── 06_directories.arb  ← dir.make, dir.list, dir.name, dir.del
│   ├── 07_globals.arb      ← snap.time, count.time, cs, locale, battery, network
│   ├── 08_full.arb         ← Everything: arb, functions, C block, shell, files, globals
│   ├── 09_extensions.arb   ← Python extension loading and calling
│   └── 10_cblock.arb       ← Inline C with variable interpolation
├── extensions/             ← Extension examples (Step 14)
│   ├── ext_example.py      ← Python extension (HTTP fetch, greeting, time hook)
│   ├── ext_c.c             ← C extension (double int, reverse string)
│   └── ext_cpp.cpp         ← C++ extension (average, uppercase)
└── docs/                   ← Documentation
    ├── spec.md             ← Full language specification (Steps 1-14)
    ├── grammar.md          ← Formal EBNF grammar (Step 15)
    ├── usage.md            ← Usage documentation (Step 17)
    ├── maintenance.md      ← Manual maintenance guide (Step 14)
    └── implementation_notes.md ← Implementation notes (Step 18)
```

## Language Features

- **File format**: `.arb` files with metadata, declarations, overrides, functions, body
- **Types**: int, float, string, boolean, array, list, and `arb` (tagged hex container)
- **Functions**: `--Function Role.Name(args) { body }` with typed/untyped params
- **Overrides**: `--OV print myprint` creates function aliases
- **Shell escapes**: `cmd{ ... }` and `ps{ ... }` with `${var}` interpolation
- **Inline C**: `c{ ... }` blocks compiled and executed natively
- **File I/O**: readFile, writeFile, buildFile, addr.hex/binary/meta, txtRC
- **Directory ops**: dir.make/list/name/del with relative path support
- **Control flow**: if/elif/else, for (range & iterable), while, break, ternary
- **Colored I/O**: `print(text, fg: red, bg: black)` with named/hex colors
- **OS globals**: snap.time, count.time, wait, cs, locale.*, battery, network, os.*
- **Extensions**: Python, C, and C++ extensions via loadExt() with hook support

## Architecture

The interpreter is a single Python file with no external dependencies (Python 3.8+ stdlib only). It uses a tree-walking approach: Lexer → Parser (AST) → Evaluator. Can be bundled with PyInstaller into a standalone executable.
