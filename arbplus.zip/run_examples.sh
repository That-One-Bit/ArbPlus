#!/bin/bash
# ArbPlus Example Runner — runs all example .arb files and shows output
# Usage: ./run_examples.sh

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INTERP="$SCRIPT_DIR/interpreter.py"

echo "============================================"
echo "  ArbPlus Interpreter — Example Runner"
echo "============================================"
echo ""

PASS=0
FAIL=0

for f in "$SCRIPT_DIR"/examples/*.arb; do
    name=$(basename "$f")
    echo "─── $name ───"
    if python3 "$INTERP" "$f" 2>&1; then
        PASS=$((PASS + 1))
    else
        FAIL=$((FAIL + 1))
    fi
    echo ""
done

echo "============================================"
echo "  Results: $PASS passed, $FAIL failed"
echo "============================================"
