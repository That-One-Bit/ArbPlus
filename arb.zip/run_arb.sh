#!/usr/bin/env bash
# ============================================================
#  ArbPlus Script Runner — double-click to run .arb files
#  Usage:  run_arb.sh  script.arb  [args...]
# ============================================================
set -euo pipefail

# --- Find the interpreter ---
ARB_HOME="${ARBPLUS_HOME:-}"

if [ -z "$ARB_HOME" ]; then
    # Try the directory where this script lives
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    if [ -f "$SCRIPT_DIR/interpreter.py" ]; then
        ARB_HOME="$SCRIPT_DIR"
    fi
fi

if [ -z "$ARB_HOME" ] || [ ! -f "$ARB_HOME/interpreter.py" ]; then
    # Walk up from the target script's directory looking for interpreter.py
    if [ $# -ge 1 ]; then
        SEARCH_DIR="$(cd "$(dirname "$1")" && pwd)"
        for _ in $(seq 1 10); do
            if [ -f "$SEARCH_DIR/interpreter.py" ]; then
                ARB_HOME="$SEARCH_DIR"
                break
            fi
            PARENT="$(dirname "$SEARCH_DIR")"
            [ "$PARENT" = "$SEARCH_DIR" ] && break
            SEARCH_DIR="$PARENT"
        done
    fi
fi

if [ -z "$ARB_HOME" ] || [ ! -f "$ARB_HOME/interpreter.py" ]; then
    echo "[ArbPlus] ERROR: Could not find interpreter.py"
    echo "[ArbPlus] Set the ARBPLUS_HOME environment variable to your ArbPlus directory."
    exit 1
fi

# --- Find Python ---
PY=""
for cmd in python3 python; do
    if command -v "$cmd" &>/dev/null; then
        PY="$cmd"
        break
    fi
done

if [ -z "$PY" ]; then
    echo "[ArbPlus] ERROR: Python is not installed or not in PATH."
    exit 1
fi

# --- Run the script ---
if [ $# -lt 1 ]; then
    echo "[ArbPlus] No script specified. Usage: run_arb.sh script.arb [args...]"
    exit 1
fi

SCRIPT="$1"
shift

echo "[ArbPlus] Running: $(basename "$SCRIPT")"
echo "========================================"
cd "$ARB_HOME"
$PY interpreter.py "$SCRIPT" "$@"
EC=$?
cd - >/dev/null 2>&1
echo "========================================"
if [ $EC -ne 0 ]; then
    echo "[ArbPlus] Script exited with code $EC"
fi
exit $EC
