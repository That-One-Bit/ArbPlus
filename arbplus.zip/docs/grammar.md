# ArbPlus Formal Grammar (EBNF)

This grammar covers all features from Steps 1–14 of the ArbPlus specification.

## Notation
- `::=` — production
- `|` — alternation
- `[...]` — optional (0 or 1)
- `{...}` — repetition (0 or more)
- `(...)` — grouping
- `"..."` — terminal string literal
- Comments follow `//`

---

## Program Structure (Step 1)

```ebnf
program       ::= [metadata] {declaration} {override} {function_def} {statement} ;

metadata      ::= "#meta" "{" {meta_entry} "}" ;
meta_entry    ::= IDENT ":" meta_value {terminator} ;
meta_value    ::= STRING | IDENT | INT | FLOAT {IDENT | ":" | STRING | INT | FLOAT} ;
                // Value tokens are accumulated until a terminator

declaration   ::= ("#use" IDENT | "#import" IDENT) {terminator} ;
override      ::= "--OV" IDENT IDENT {terminator} ;
function_def  ::= "--Function" IDENT "." IDENT "(" [param_list] ")" "{" {statement} "}" ;
param_list    ::= param {"," param} ;
param         ::= IDENT [":" type_name] ;

terminator    ::= ";" | ">" | NEWLINE ;
```

## Comments & Encoding (Step 1)

```ebnf
comment       ::= "//" {any_char_except_terminator} terminator
              | "/*" {any_char} "*/" ;
              // File encoding: UTF-8
```

## Types (Step 5)

```ebnf
type_name     ::= "int" | "float" | "string" | "boolean" | "array" | "list" | "arb" ;

arb_tag       ::= INT ;   // Hex literal: 0x01, 0x02, 0x03, 0x04, 0x10, 0xFF
```

### arb Sub-Type Tag Map
| Tag Name | Hex Prefix |
|----------|-----------|
| str      | 0x01      |
| int      | 0x02      |
| float    | 0x03      |
| bool     | 0x04      |
| image    | 0x10      |
| raw      | 0xFF      |

## Variables & Assignment (Step 6)

```ebnf
var_decl      ::= ("let" | "const") IDENT [":" type_name] "=" expression ;
assignment    ::= IDENT "=" expression ;
swap          ::= IDENT "<>" IDENT ;
```

## Functions (Step 7)

```ebnf
call          ::= name "(" [arg_list] ")" ;
name          ::= IDENT {"." IDENT} ;   // supports dotted names: dir.list, snap.time
arg_list      ::= arg {"," arg} ;
arg           ::= expression | IDENT ":" kwarg_value ;
kwarg_value   ::= STRING | IDENT | INT | FLOAT | expression ;
              // Bare IDENT in kwarg position → string literal
```

## Expressions (Steps 5, 6, 7, 10)

```ebnf
expression    ::= ternary ;

ternary       ::= or_expr ["?" ternary ":" ternary] ;

or_expr       ::= and_expr {"||" and_expr} ;
and_expr     ::= not_expr {"&&" not_expr} ;
not_expr     ::= "not" not_expr | comparison ;

comparison    ::= concat_expr {comp_op concat_expr} ;
comp_op       ::= "==" | "!=" | "<" | "<=" | ">" | ">=" ;

concat_expr   ::= add_expr {".." add_expr} ;

add_expr      ::= mul_expr {("+" | "-") mul_expr} ;
mul_expr      ::= unary_expr {("*" | "/" | "%" | "^") unary_expr} ;
unary_expr    ::= ("-" | "+") unary_expr | postfix ;

postfix       ::= primary {index | member_access | call_args} ;
index         ::= "[" expression "]" ;
member_access ::= "." IDENT ["(" [arg_list] ")"] ;
call_args     ::= "(" [arg_list] ")" ;

primary       ::= INT | FLOAT | STRING | "true" | "false"
              | IDENT
              | "(" expression ")"
              | list_literal
              | arb_literal ;

list_literal  ::= "[" [expression {"," expression}] "]" ;

arb_literal   ::= "arb{" [arb_element {"," arb_element}] "}" ;
arb_element   ::= arb_tag "(" expression ")" ;
```

## Statement Terminators (Step 1)

```ebnf
// ; is the primary terminator (C-family convention, matches inline C blocks)
// > is an alternative (aesthetic choice)
// Mixing is legal; each statement ends at the first terminator encountered
// NEWLINE is a soft terminator (statement continues across lines)
```

## Shell Escapes (Step 4)

```ebnf
shell_block   ::= ("cmd" | "ps") "{" raw_text "}" ;
              // raw_text: everything between { and matching }, preserving whitespace
              // Variable interpolation: ${var} → variable value
```

## Inline C (Step 1)

```ebnf
c_block       ::= "c" "{" raw_c_code "}" ;
              // raw_c_code: C source code, compiled and executed
              // Variable interpolation: ${var} → variable value (as C literal)
```

## Control Flow (Step 10)

```ebnf
if_stmt       ::= "if" "(" expression ")" "{" {statement} "}"
                  {"elif" "(" expression ")" "{" {statement} "}"} 
                  ["else" "{" {statement} "}"] ;

for_stmt      ::= "for" "(" for_spec ")" "{" {statement} "}" ;
for_spec      ::= IDENT "in" expression
              | IDENT "=" expression "to" expression ["step" expression] ;

while_stmt    ::= "while" "(" expression ")" "{" {statement} "}" ;

break_stmt    ::= "break" [IDENT] ;   // optional label (not evaluated in v1.0)

return_stmt   ::= "return" [expression] ;

exit_stmt     ::= ("exit" | "quit") [expression] ;  // expression = exit code

end_stmt     ::= "end" ;   // no-op (blocks are {} delimited)
```

## I/O with Color (Step 11)

```ebnf
print_stmt    ::= "print" "(" [arg_list] ")" ;
              // kwargs: fg: color, bg: color
              // color: named (red, cyan, ...) or hex (#RRGGBB)

input_expr    ::= "input" "(" [arg_list] ")" ;
              // kwargs: fg: color, bg: color
              // Returns: string (user input)
```

### Color Values
```ebnf
color_value   ::= color_name | hex_color ;
color_name    ::= "black" | "red" | "green" | "yellow" | "blue"
              | "magenta" | "cyan" | "white"
              | "bright_black" | "bright_red" | "bright_green"
              | "bright_yellow" | "bright_blue" | "bright_magenta"
              | "bright_cyan" | "bright_white" ;
hex_color     ::= "#" HEX_DIGIT HEX_DIGIT HEX_DIGIT HEX_DIGIT HEX_DIGIT HEX_DIGIT ;
```

## File Operations (Steps 8, 9)

```ebnf
// Reading
read_file     ::= "readFile" "(" expression ")" ;
file_exists   ::= "fileExists" "(" expression ")" ;

// Addressing
addr_hex      ::= "addr" "." "hex" "(" expression ")" ;
addr_binary   ::= "addr" "." "binary" "(" expression ")" ;
addr_meta     ::= "addr" "." "meta" "(" expression ")" ;
txt_rc        ::= "txtRC" "(" expression "," expression ["," expression] ")" ;

// Image
encode_image  ::= "encodeImage" "(" expression ")" ;
decode_image  ::= "decodeImage" "(" expression ["," expression] ")" ;

// Media/Browser
open_media    ::= "openMedia" "(" expression ")" ;
open_browser  ::= "openBrowser" "(" expression ")" ;

// Writing
write_file    ::= "writeFile" "(" expression "," expression ["," "mode" ":" expression] ")" ;
build_file    ::= "buildFile" "(" expression "," expression ")" ;
              // mode: "overwrite" (default) | "error"

// Directory
dir_list      ::= "dir" "." "list" "(" expression ["," expression] ")" ;
dir_name      ::= "dir" "." "name" "(" expression "," expression ")" ;
dir_make      ::= "dir" "." "make" "(" expression ["," expression] ")" ;
dir_del       ::= "dir" "." "del" "(" expression ")" ;
```

### Path Resolution (Step 9)
```ebnf
path          ::= absolute_path | relative_path ;
absolute_path ::= "/" {path_segment} ;
relative_path ::= ("./" | "../" {"/.."} | ) {path_segment} ;
              // Resolved relative to the running script's directory
```

## OS Globals (Step 12)

```ebnf
// Time
snap_time     ::= "snap" "." "time" "(" [time_kwargs] ")" ;
              // One-shot snapshot; kwargs: Year, Month, Day, Hour, Minute, Second, MS

count_time    ::= "count" "." "time" "(" [time_kwargs] ")" ;
              // Live sampling; kwargs: Year, Month, Day, Hour, Minute, Second, MS, interval

time_kwargs   ::= time_kwarg {"," time_kwarg} ;
time_kwarg    ::= ("Year" | "Month" | "Day" | "Hour" | "Minute" | "Second" | "MS" | "interval")
                  ":" expression ;

wait_stmt     ::= "wait" "(" [expression {"," expression}] ")" ;
              // Args: minutes, seconds, milliseconds (positional)

// Color Scheme
cs_call       ::= "cs" "(" ")"           // returns: "light" | "dark"
              | "cs" "(" expression ")" ; // returns: boolean

// Locale
locale_prf    ::= "locale" "." "prf" ;    // preferred locale (string)
locale_cur    ::= "locale" "." "cur" ;   // current locale (string)
locale_alt    ::= "locale" "." "alt" ;   // alternatives (string)
locale_check  ::= "locale" "." "check" "(" expression ")" ;  // boolean

// Other globals
battery       ::= "battery" "(" ")" ;
network       ::= "network" "(" ")" ;
screen        ::= "screen" "(" ")" ;
os_name       ::= "os" "." "name" ;
os_version    ::= "os" "." "version" ;
```

### Global Addition Pattern
```ebnf
// New globals follow the dot-notation pattern:
// namespace.property (no-arg → value, with-arg → boolean)
// namespace.check(value) → boolean
```

## Extensions (Step 13)

```ebnf
load_ext      ::= "loadExt" "(" expression ["," expression] ")" ;
              // First arg: path; Second arg: language ("python" | "c" | "c++" | "cpp")

ext_call      ::= "ext" "." IDENT "(" [arg_list] ")" ;
              // Extension functions called via ext. namespace
```

### C/C++ ABI
```ebnf
c_entry       ::= "void" "arbplus_register" "(" "ArbEngine*" engine ")" ;
c_register    ::= engine "->" "register_func" "(" string "," function_pointer ")" ;
c_hook        ::= engine "->" "register_hook" "(" string "," function_pointer ")" ;
```

### Python ABI
```ebnf
py_entry      ::= "def" "register" "(" "engine" ")" ":" ... ;
py_register   ::= engine "." "register_extension" "(" string "," callable ")" ;
py_hook       ::= engine "." "register_hook" "(" string "," callable ")" ;
```

## Complete Program Grammar

```ebnf
program       ::= [metadata_block] {declaration} {override} {function_def} body ;
metadata_block ::= "#meta" "{" {meta_entry} "}" ;
meta_entry    ::= IDENT ":" meta_value {terminator} ;
declaration   ::= ("#use" IDENT | "#import" IDENT) {terminator} ;
override      ::= "--OV" IDENT IDENT {terminator} ;
function_def  ::= "--Function" IDENT "." IDENT "(" [param_list] ")" "{" body "}" ;
body          ::= {statement} ;

statement     ::= var_decl | assignment | swap | if_stmt | for_stmt
              | while_stmt | break_stmt | return_stmt | exit_stmt | end_stmt
              | c_block | shell_block | expression_statement {terminator} ;

expression_statement ::= expression ;
              // If followed by "=", treated as assignment
              // If followed by "<>", treated as swap
```

## Operator Precedence (lowest to highest)

| Level | Operators | Description |
|-------|----------|-------------|
| 1 | `? :` | Ternary |
| 2 | `\|\|` | Logical OR |
| 3 | `&&` | Logical AND |
| 4 | `not` | Logical NOT (unary) |
| 5 | `== != < <= > >=` | Comparison |
| 6 | `..` | String concatenation |
| 7 | `+ -` | Addition/subtraction |
| 8 | `* / % ^` | Multiplication/division/power |
| 9 | `- +` (unary) | Unary minus/plus |
| 10 | `[] . ()` | Postfix (index, member, call) |

## Literals

```ebnf
INT           ::= DIGIT {DIGIT} | "0x" HEX_DIGIT {HEX_DIGIT} ;
FLOAT         ::= DIGIT {DIGIT} "." DIGIT {DIGIT} ;
STRING        ::= '"' {string_char} '"' | "'" {string_char} "'" ;
string_char   ::= any_char_except_quote | escape_seq ;
escape_seq    ::= "\" ("n" | "t" | "r" | "\" | quote | "0") ;
BOOLEAN       ::= "true" | "false" ;
HEX_DIGIT     ::= DIGIT | "a".."f" | "A".."F" ;
```

## Whitespace & Encoding

```ebnf
// Whitespace (spaces, tabs, newlines) is ignored between tokens
// Newlines are soft terminators (statements continue across lines)
// Statement terminators: ; (primary), > (alternative)
// File encoding: UTF-8
```
